﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Navig
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class End : ContentPage
    {
        StackLayout stackInfo = new StackLayout();
        public End(string[]_dataString)
        {
            NavigationPage.SetHasBackButton(this,false);

            string[] dataString = _dataString;
            StackLayout stack = new StackLayout();
            Button button = new Button { Text = "В начало" };
            button.Clicked += (sender, e) =>
            {
                Navigation.PushAsync(new MainPage());
            };

            foreach (string item in dataString)
            {
                stack.Children.Add(new Label { Text = item });
            }

            stack.Children.Add(button);
            stack.Children.Add(stackInfo);

            Content = stack;
        }
        protected override void OnAppearing()
        {
            stackInfo.Children.Clear();
            foreach (Page item in Navigation.NavigationStack)
            {
                stackInfo.Children.Add(new Label { Text = $"{item.GetType() }" });
            }
        }
    }
}