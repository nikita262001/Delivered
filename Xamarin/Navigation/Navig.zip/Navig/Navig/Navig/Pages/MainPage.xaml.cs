﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace Navig
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        StackLayout stackInfo = new StackLayout();
        public MainPage()
        {
            string[] dataString = new string[3];
            StackLayout stack = new StackLayout();
            Entry entry = new Entry();
            Button button = new Button { Text = "Переход на вторую страницу" };
            button.Clicked += (sender, e) =>
            {
                dataString[0] = entry.Text;
                Navigation.PushAsync(new Page2(dataString));
            };

            stack.Children.Add(entry);
            stack.Children.Add(button);
            stack.Children.Add(stackInfo);

            foreach (string item in dataString)
            {
                stack.Children.Add(new Label { Text = item });
            }
            Content = stack;
        }
        protected override void OnAppearing()
        {
            List<Page> stackNavi = Navigation.NavigationStack.ToList();
            foreach (Page item in stackNavi)
            {
                if (stackNavi.Last() != item)
                {
                    Navigation.RemovePage(item);
                }
            }
            StackInfo();
        }
        private void StackInfo()
        {
            stackInfo.Children.Clear();
            foreach (Page item in Navigation.NavigationStack)
            {
                stackInfo.Children.Add(new Label { Text = $"{item.GetType() }" });
            }
        }
    }
}