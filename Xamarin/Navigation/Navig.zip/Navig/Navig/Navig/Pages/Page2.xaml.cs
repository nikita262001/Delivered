﻿using Navig.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Navig
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page2 : ContentPage
    {
        StackLayout stackInfo = new StackLayout();
        public Page2(string[]_dataString)
        {
            string[] dataString = _dataString;
            StackLayout stack = new StackLayout();
            Entry entry = new Entry();
            Button button = new Button { Text = "Переход на вторую страницу" };
            button.Clicked += (sender, e) =>
            {
                dataString[1] = entry.Text;
                Navigation.PushAsync(new Page31(dataString));
            };
            foreach (string item in dataString)
            {
                stack.Children.Add(new Label { Text = item });
            }

            stack.Children.Add(entry);
            stack.Children.Add(button);
            stack.Children.Add(stackInfo);

            Content = stack;
        }
        protected override void OnAppearing()
        {
            stackInfo.Children.Clear();
            foreach (Page item in Navigation.NavigationStack)
            {
                stackInfo.Children.Add(new Label { Text = $"{item.GetType() }" });
            }
        }
    }
}