﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUserss
{
    public class Users
    {
        private string login;
        private string password;
        private string name;
        private string surname;
        private string email;
        private int phone;
        private int flashCode;

        private List<Сharacter> person = new List<Сharacter>();

        public string Login { get => login; set => login = value; }
        public string Password { get => password; set => password = value; }
        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string Email { get => email; set => email = value; }
        public int Phone { get => phone; set => phone = value; }
        public int FlashCode { get => flashCode; set => flashCode = value; }
        public List<Сharacter> Person { get => person; set => person = value; }
    }
}
