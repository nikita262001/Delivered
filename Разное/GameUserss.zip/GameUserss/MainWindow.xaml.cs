﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GameUserss
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Users users;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "")
                login.Text = " ";
            if (password.Text == "")
                password.Text = " ";
            if (name.Text == "")
                name.Text = " ";
            if (surname.Text == "")
                surname.Text = " ";
            if (email.Text == "")
                email.Text = " ";
            if (phone.Text == "")
                phone.Text = "0";
            if (email.Text == "")
                email.Text = " ";


            users = new Users()
            {
                Login = login.Text,
                Password = password.Text,
                Name = name.Text,
                Surname = surname.Text,
                Email = email.Text,
                Phone = Convert.ToInt32(phone.Text),
                FlashCode = Convert.ToInt32(flashCode.Content),
            };

            this.Hide();
            AccountPerson page = new AccountPerson(users);
            page.Show();
        }

        private void Button_ClickText(object sender, RoutedEventArgs e)
        {
            Button txtB = (Button)sender;
            flashCode.Content += $"{txtB.Content}";
        }

        private void Button_ClickRemove(object sender, RoutedEventArgs e)
        {
            string txt = (string)flashCode.Content;
            if (txt.Length != 0)
            {
                flashCode.Content = txt.Remove(txt.Length - 1);
            }
        }

        private void phone_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!(Char.IsDigit(e.Text, 0) || (e.Text == ".")
               && (!phone.Text.Contains(".")
               && phone.Text.Length != 0)))
            {
                e.Handled = true;
            }
        }

        private async void Button_ClickLogin(object sender, RoutedEventArgs e)
        {
            var client = new MongoClient("mongodb://localhost");
            var database = client.GetDatabase("TestUsers");
            IMongoCollection<BsonDocument> collectionDoc = database.GetCollection<BsonDocument>("UsersGame");

            var peopleL = await collectionDoc.Find(new BsonDocument("Login", login.Text)).ToListAsync();

            stackUsers.Children.Clear();
            foreach (BsonDocument p1 in peopleL)
            {
                stackUsers.Children.Add(new Label { Content = $"{p1.ToString()}", });
            }
        }
        private async void Button_ClickPassword(object sender, RoutedEventArgs e)
        {
            var client = new MongoClient("mongodb://localhost");
            var database = client.GetDatabase("TestUsers");
            IMongoCollection<BsonDocument> collectionDoc = database.GetCollection<BsonDocument>("UsersGame");

            var peopleL = await collectionDoc.Find(new BsonDocument("Password", password.Text)).ToListAsync();

            stackUsers.Children.Clear();
            foreach (BsonDocument p1 in peopleL)
            {
                stackUsers.Children.Add(new Label { Content = $"{p1.ToString()}", });
            }
        }
        private async void Button_ClickFindLogAndPas(object sender, RoutedEventArgs e)
        {
            var client = new MongoClient("mongodb://localhost");
            var database = client.GetDatabase("TestUsers");
            IMongoCollection<BsonDocument> collectionDoc = database.GetCollection<BsonDocument>("UsersGame");

            var peopleL = await collectionDoc.Find(new BsonDocument("Password", password.Text)).ToListAsync();

            stackUsers.Children.Clear();
            foreach (BsonDocument p1 in peopleL)
            {
                if (p1.GetElement("Login").Value == login.Text)
                {
                    stackUsers.Children.Add(new Label { Content = $"{p1.ToString()}", });
                }
            }
        }
    }
}
