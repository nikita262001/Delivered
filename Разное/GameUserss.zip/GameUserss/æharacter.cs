﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUserss
{
    public class Сharacter
    {
        string classСharacter = null;
        int force;//сила
        int agility;//ловкость
        int intelligence;//интелект

        List<object> items = new List<object>();

        public string ClassСharacter { get => classСharacter; set => classСharacter = value; }
        public int Force { get => force; set => force = value; }
        public int Agility { get => agility; set => agility = value; }
        public int Intelligence { get => intelligence; set => intelligence = value; }
        public List<object> Items { get => items; set => items = value; }

    }
}
