﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GameUserss
{
    /// <summary>
    /// Логика взаимодействия для AccountPerson.xaml
    /// </summary>
    public partial class AccountPerson : Window
    {
        bool newUser = true;
        Users users;
        public AccountPerson(Users newUsers)
        {
            InitializeComponent();
            users = newUsers;
            foreach (Сharacter item in users.Person)
            {
                string items = "";
                foreach (object itemString in item.Items)
                {
                    items += $"{itemString.ToString()}. ";
                }
                Label label = new Label()
                {
                    Content = $"Класс персонажа:{item.ClassСharacter}, Ловкость:{item.Agility}, Сила:{item.Force}, Интелект:{item.Intelligence}, Items:{items}",
                };
                stack.Children.Add(label);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            NewCharacter page = new NewCharacter(users);
            page.Show();
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            var client = new MongoClient("mongodb://localhost");
            var database = client.GetDatabase("TestUsers");
            IMongoCollection<BsonDocument> collectionDoc = database.GetCollection<BsonDocument>("UsersGame");

            #region Добавление, начало отбора по Login
            var peopleL = await collectionDoc.Find(new BsonDocument("Login", users.Login)).ToListAsync();
            foreach (BsonDocument p1 in peopleL)
            {
                if (users.Password == p1.GetElement("Password").Value)
                {
                    await collectionDoc.ReplaceOneAsync(new BsonDocument("Password", users.Password), users.ToBsonDocument(), new UpdateOptions { IsUpsert = true });
                    newUser = false;
                }
            }
            #endregion

            #region Добавление, начало отбора по Password
            var peopleP = await collectionDoc.Find(new BsonDocument("Password", users.Password)).ToListAsync();
            foreach (BsonDocument p1 in peopleP)
            {
                if (users.Login == p1.GetElement("Login").Value)
                {
                    await collectionDoc.ReplaceOneAsync(new BsonDocument("Login", users.Login), users.ToBsonDocument(), new UpdateOptions { IsUpsert = true });
                    newUser = false;
                }
            }
            #endregion

            if (newUser)
            {
                await collectionDoc.InsertOneAsync(users.ToBsonDocument());
            }

            this.Hide();
            MainWindow page = new MainWindow();
            page.Show();
        }

    }
}
