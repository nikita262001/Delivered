﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GameUserss
{
    /// <summary>
    /// Логика взаимодействия для NewCharacter.xaml
    /// </summary>
    public partial class NewCharacter : Window
    {
        Users users;
        public NewCharacter(Users newUsers)
        {
            InitializeComponent();
            users = newUsers;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            users.Person.Add(new Сharacter() 
            {
                ClassСharacter ="Маг",
                Agility = 10,
                Force = 10,
                Intelligence = 20,
                Items = {"Посох" },
            });

            this.Hide();
            AccountPerson page = new AccountPerson(users);
            page.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            users.Person.Add(new Сharacter()
            {
                ClassСharacter = "Воин",
                Agility = 10,
                Force = 20,
                Intelligence = 10,
                Items = { "Короткий меч", "Щит" },
            });

            this.Hide();
            AccountPerson page = new AccountPerson(users);
            page.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            users.Person.Add(new Сharacter()
            {
                ClassСharacter = "Разбойник",
                Agility = 20,
                Force = 10,
                Intelligence = 10,
                Items = { "Короткий лук", "Кинжал" },
            });

            this.Hide();
            AccountPerson page = new AccountPerson(users);
            page.Show();
        }
    }
}
